export default function Clientes(){
    return(
        <section className="bg-white w-full flex flex-col items-center">
            <h1>Estas son algunas de las empresas que confian en nosotros</h1>
        </section>
    )
}